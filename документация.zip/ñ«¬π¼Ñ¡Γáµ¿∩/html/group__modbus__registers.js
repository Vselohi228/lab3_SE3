var group__modbus__registers =
[
    [ "eMBRegCoilsCB", "group__modbus__registers.html#ga88d9b719291515c60eee1bf9ffa1dd02", null ],
    [ "eMBRegDiscreteCB", "group__modbus__registers.html#ga38101f5da54af137e210a3b8b9fa3887", null ],
    [ "eMBRegHoldingCB", "group__modbus__registers.html#ga10d37e1d80224bf3b1eeb9e246d7582e", null ],
    [ "eMBRegInputCB", "group__modbus__registers.html#ga7816677520b1eb2ebecf15060a41bc81", null ]
];