var _practical_socket_8h =
[
    [ "SocketException", "class_socket_exception.html", "class_socket_exception" ],
    [ "Socket", "class_socket.html", "class_socket" ],
    [ "CommunicatingSocket", "class_communicating_socket.html", "class_communicating_socket" ],
    [ "TCPSocket", "class_t_c_p_socket.html", "class_t_c_p_socket" ],
    [ "TCPServerSocket", "class_t_c_p_server_socket.html", "class_t_c_p_server_socket" ],
    [ "UDPSocket", "class_u_d_p_socket.html", "class_u_d_p_socket" ]
];