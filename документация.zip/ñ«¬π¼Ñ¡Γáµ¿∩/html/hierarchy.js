var hierarchy =
[
    [ "exception", null, [
      [ "SocketException", "class_socket_exception.html", null ]
    ] ],
    [ "Socket", "class_socket.html", [
      [ "CommunicatingSocket", "class_communicating_socket.html", [
        [ "TCPSocket", "class_t_c_p_socket.html", null ],
        [ "UDPSocket", "class_u_d_p_socket.html", null ]
      ] ],
      [ "TCPServerSocket", "class_t_c_p_server_socket.html", null ]
    ] ],
    [ "xMBFunctionHandler", "structx_m_b_function_handler.html", null ]
];