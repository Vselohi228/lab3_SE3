var searchData=
[
  ['usmbcrc16_0',['usMBCRC16',['../mbcrc_8c.html#abc48f359fd99e303016c8b74cc82c3ff',1,'usMBCRC16(UCHAR *pucFrame, USHORT usLen):&#160;mbcrc.c'],['../mbcrc_8h.html#abc48f359fd99e303016c8b74cc82c3ff',1,'usMBCRC16(UCHAR *pucFrame, USHORT usLen):&#160;mbcrc.c']]]
];
