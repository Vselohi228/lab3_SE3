var searchData=
[
  ['_7esocket_0',['~Socket',['../class_socket.html#aeac4eb6379a543d38ed88977d3b6630a',1,'Socket']]],
  ['_7esocketexception_1',['~SocketException',['../class_socket_exception.html#a659557c899329aea01977c980c4db9b9',1,'SocketException']]]
];
