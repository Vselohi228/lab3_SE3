var searchData=
[
  ['auccrchi_0',['aucCRCHi',['../mbcrc_8c.html#a3c8c243843ff5f7d637d6e515468a6e0',1,'mbcrc.c']]],
  ['auccrclo_1',['aucCRCLo',['../mbcrc_8c.html#ac7191e1b186e144f5c19d1fc78c09719',1,'mbcrc.c']]]
];
