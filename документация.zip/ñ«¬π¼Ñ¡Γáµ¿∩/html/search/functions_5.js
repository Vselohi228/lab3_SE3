var searchData=
[
  ['getforeignaddress_0',['getForeignAddress',['../class_communicating_socket.html#a13f9eca30ef56836cf23c163c848c09e',1,'CommunicatingSocket']]],
  ['getforeignport_1',['getForeignPort',['../class_communicating_socket.html#a184fbb4775184b87ebd886a5587eb1a3',1,'CommunicatingSocket']]],
  ['getlocaladdress_2',['getLocalAddress',['../class_socket.html#a0fca07bdfa97874fba1a17995ed7cda3',1,'Socket']]],
  ['getlocalport_3',['getLocalPort',['../class_socket.html#ae01143b667d69483a2f53d0f4ce7eeed',1,'Socket']]]
];
