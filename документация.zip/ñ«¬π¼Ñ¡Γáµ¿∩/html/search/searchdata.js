var indexSectionsWithContent =
{
  0: "abempsuvx",
  1: "x",
  2: "m",
  3: "epuvx",
  4: "aepux",
  5: "p",
  6: "e",
  7: "ems",
  8: "bm",
  9: "mu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "groups"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Классы",
  2: "Файлы",
  3: "Функции",
  4: "Переменные",
  5: "Определения типов",
  6: "Перечисления",
  7: "Элементы перечислений",
  8: "Макросы",
  9: "Группы"
};

