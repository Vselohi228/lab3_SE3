var searchData=
[
  ['raw_5ftype_0',['raw_type',['../_practical_socket_8cpp.html#aba7a57aadc5c75eaab8ee698d0fa6608',1,'PracticalSocket.cpp']]]
];
