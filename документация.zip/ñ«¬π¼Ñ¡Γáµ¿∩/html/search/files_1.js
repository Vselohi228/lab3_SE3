var searchData=
[
  ['practicalsocket_2ecpp_0',['PracticalSocket.cpp',['../_practical_socket_8cpp.html',1,'']]],
  ['practicalsocket_2eh_1',['PracticalSocket.h',['../_practical_socket_8h.html',1,'']]]
];
