var class_socket_exception =
[
    [ "SocketException", "class_socket_exception.html#abb5bcecd9d9e20868c237ec5a82cf5c3", null ],
    [ "~SocketException", "class_socket_exception.html#a659557c899329aea01977c980c4db9b9", null ],
    [ "what", "class_socket_exception.html#a534b0625abe62cad2bae94758aa6eb42", null ],
    [ "userMessage", "class_socket_exception.html#adcfeba6d4ce5754b48ae9d37b07a7e87", null ]
];