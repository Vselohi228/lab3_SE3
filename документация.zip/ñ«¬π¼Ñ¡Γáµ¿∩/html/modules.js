var modules =
[
    [ "Modbus", "group__modbus.html", "group__modbus" ],
    [ "Modbus Registers", "group__modbus__registers.html", "group__modbus__registers" ],
    [ "Modbus Configuration", "group__modbus__cfg.html", "group__modbus__cfg" ],
    [ "Utilities", "group__modbus__utils.html", "group__modbus__utils" ]
];