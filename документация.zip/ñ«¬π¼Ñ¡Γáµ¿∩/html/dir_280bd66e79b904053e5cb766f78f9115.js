var dir_280bd66e79b904053e5cb766f78f9115 =
[
    [ "PracticalSocket.cpp", "_practical_socket_8cpp.html", "_practical_socket_8cpp" ],
    [ "PracticalSocket.h", "_practical_socket_8h.html", "_practical_socket_8h" ]
];