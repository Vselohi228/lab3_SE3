var structx_m_b_function_handler =
[
    [ "pxHandler", "structx_m_b_function_handler.html#ab2ea74b69155c337ec9c0d2e229160ce", null ],
    [ "ucFunctionCode", "structx_m_b_function_handler.html#acf0798484cf2b6b1ec21389d3f2a997c", null ]
];