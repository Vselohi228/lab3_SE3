var _practical_socket_8cpp =
[
    [ "raw_type", "_practical_socket_8cpp.html#aba7a57aadc5c75eaab8ee698d0fa6608", null ],
    [ "fillAddr", "_practical_socket_8cpp.html#a155e03535e1d5c1f5df7ceafe63dbdb0", null ]
];