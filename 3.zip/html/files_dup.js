var files_dup =
[
    [ "freemodbus-v1.5.0", "dir_e15da0c04fcf3530559bdb8397602a27.html", "dir_e15da0c04fcf3530559bdb8397602a27" ],
    [ "Practical C++ Sockets", "dir_280bd66e79b904053e5cb766f78f9115.html", "dir_280bd66e79b904053e5cb766f78f9115" ]
];