var searchData=
[
  ['socket_0',['Socket',['../class_socket.html',1,'']]],
  ['socketexception_1',['SocketException',['../class_socket_exception.html',1,'']]]
];
