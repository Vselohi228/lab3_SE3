var searchData=
[
  ['cleanup_0',['cleanUp',['../class_socket.html#ac5060aeb501044044351d5a85b3fc95f',1,'Socket']]],
  ['communicatingsocket_1',['CommunicatingSocket',['../class_communicating_socket.html#a0017517b8d6e761fde0c40475af3b2ab',1,'CommunicatingSocket::CommunicatingSocket(int type, int protocol)'],['../class_communicating_socket.html#a27d758db782b3be7d28741e92cb613d1',1,'CommunicatingSocket::CommunicatingSocket(int newConnSD)']]],
  ['connect_2',['connect',['../class_communicating_socket.html#a9192374d9baab8e189860aa8d913683c',1,'CommunicatingSocket']]]
];
