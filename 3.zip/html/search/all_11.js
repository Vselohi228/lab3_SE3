var searchData=
[
  ['what_0',['what',['../class_socket_exception.html#a534b0625abe62cad2bae94758aa6eb42',1,'SocketException']]]
];
