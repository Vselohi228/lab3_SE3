var indexSectionsWithContent =
{
  0: "abcdefgjlmoprstuvwx~",
  1: "cstux",
  2: "mpr",
  3: "acdefgjloprstuvwx~",
  4: "aepsux",
  5: "pr",
  6: "e",
  7: "ems",
  8: "t",
  9: "bm",
  10: "mu",
  11: "l"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "related",
  9: "defines",
  10: "groups",
  11: "pages"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Классы",
  2: "Файлы",
  3: "Функции",
  4: "Переменные",
  5: "Определения типов",
  6: "Перечисления",
  7: "Элементы перечислений",
  8: "Друзья",
  9: "Макросы",
  10: "Группы",
  11: "Страницы"
};

