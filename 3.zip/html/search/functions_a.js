var searchData=
[
  ['recv_0',['recv',['../class_communicating_socket.html#a7cf1fd470c0060171b68df9f68c7bd01',1,'CommunicatingSocket']]],
  ['recvfrom_1',['recvFrom',['../class_u_d_p_socket.html#abcd5c064e2496bd8b1888fd4e1b68949',1,'UDPSocket']]],
  ['resolveservice_2',['resolveService',['../class_socket.html#a982c63b25c5b756321a74074a275adbc',1,'Socket']]]
];
