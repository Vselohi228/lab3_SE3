var searchData=
[
  ['sockdesc_0',['sockDesc',['../class_socket.html#ad5704d2fdfb062139e1f88831617bbfb',1,'Socket']]]
];
