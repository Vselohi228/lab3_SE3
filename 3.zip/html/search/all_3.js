var searchData=
[
  ['disconnect_0',['disconnect',['../class_u_d_p_socket.html#a7482e8e61cef160e1a7c0d6ac15c01be',1,'UDPSocket']]]
];
