var mbconfig_8h =
[
    [ "MB_ASCII_ENABLED", "group__modbus__cfg.html#gae4accc470cf44e38b4011213a93a2adc", null ],
    [ "MB_ASCII_TIMEOUT_SEC", "group__modbus__cfg.html#ga90fe92ab8f17c76c6e48dbbab8986446", null ],
    [ "MB_ASCII_TIMEOUT_WAIT_BEFORE_SEND_MS", "group__modbus__cfg.html#ga22fd01f62670a71ab137e16118c37ca2", null ],
    [ "MB_FUNC_HANDLERS_MAX", "group__modbus__cfg.html#ga1dd115d6338ef87c83aaa23809792f25", null ],
    [ "MB_FUNC_OTHER_REP_SLAVEID_BUF", "group__modbus__cfg.html#ga4c376ec5ec8bea2ccfe067cd8c05db06", null ],
    [ "MB_FUNC_OTHER_REP_SLAVEID_ENABLED", "group__modbus__cfg.html#ga580ff483eb8b3fbfc23115808d7025c9", null ],
    [ "MB_FUNC_READ_COILS_ENABLED", "group__modbus__cfg.html#ga0a699b69e28d21c32c95affe08e04112", null ],
    [ "MB_FUNC_READ_DISCRETE_INPUTS_ENABLED", "group__modbus__cfg.html#ga76bb577b6d66b4e45571f7e46b04b134", null ],
    [ "MB_FUNC_READ_HOLDING_ENABLED", "group__modbus__cfg.html#ga2427219b5788299b59972102db511df8", null ],
    [ "MB_FUNC_READ_INPUT_ENABLED", "group__modbus__cfg.html#ga18432b6043942aa4b9e5f14c0543e663", null ],
    [ "MB_FUNC_READWRITE_HOLDING_ENABLED", "group__modbus__cfg.html#gae62a61cbd68a80de8c7ee268a5934ea3", null ],
    [ "MB_FUNC_WRITE_COIL_ENABLED", "group__modbus__cfg.html#ga3bb42e153880ea5312eaa42bb671ee50", null ],
    [ "MB_FUNC_WRITE_HOLDING_ENABLED", "group__modbus__cfg.html#gae8aa746269641b5fe032b81aafd93521", null ],
    [ "MB_FUNC_WRITE_MULTIPLE_COILS_ENABLED", "group__modbus__cfg.html#ga1973cf9a66e8738ee06681443259b78f", null ],
    [ "MB_FUNC_WRITE_MULTIPLE_HOLDING_ENABLED", "group__modbus__cfg.html#gaafa15ddf4a433ab3149178ba8199e8e2", null ],
    [ "MB_RTU_ENABLED", "group__modbus__cfg.html#ga00b7b4d768c9489b5022832db253a71c", null ],
    [ "MB_TCP_ENABLED", "group__modbus__cfg.html#ga93a17168bbe8c49e45ce6405cb4c1afb", null ]
];