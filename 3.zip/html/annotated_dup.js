var annotated_dup =
[
    [ "CommunicatingSocket", "class_communicating_socket.html", "class_communicating_socket" ],
    [ "Socket", "class_socket.html", "class_socket" ],
    [ "SocketException", "class_socket_exception.html", "class_socket_exception" ],
    [ "TCPServerSocket", "class_t_c_p_server_socket.html", "class_t_c_p_server_socket" ],
    [ "TCPSocket", "class_t_c_p_socket.html", "class_t_c_p_socket" ],
    [ "UDPSocket", "class_u_d_p_socket.html", "class_u_d_p_socket" ],
    [ "xMBFunctionHandler", "structx_m_b_function_handler.html", "structx_m_b_function_handler" ]
];